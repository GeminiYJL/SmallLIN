package cn.campsg.java.experiment;

import java.util.Scanner;

public class FreeFall {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("请输入弹跳次数：");
		int times = in.nextInt();//获取用户输入的球体弹跳次数
		int height = 10000;
		for(int i=0;i<times;i++) {
			height = height/2;
			if(height==0) {
				System.out.println("第"+i+"次反弹后，球体落地");
			}
		}
		System.out.println(times+"次反弹后，当前球体的高度是："+height);
		
		
		in.close();
	}
}
